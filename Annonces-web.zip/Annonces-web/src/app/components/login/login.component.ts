import { Component, OnInit } from '@angular/core';
import { CommonsService } from 'src/app/services/commons.service';
import { Router } from '@angular/router';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm = new FormGroup({
		email: new FormControl(),
		password: new FormControl()
	});

  constructor(private commonService: CommonsService, private router: Router) { }

  ngOnInit() {}

  // Login
	login(formValue: any) {
		this.commonService.login(formValue.email, formValue.password).subscribe(user => {
			this.commonService.setConnectedUser(user);
			this.commonService.setIsAuthenticate(true);
			this.navigateToAdvertsList();
		});
	}

	//Navigate to adverts-list
	navigateToAdvertsList() {
		this.router.navigateByUrl('adverts/list');
	}

	//Navigate to register
	navigateToRegister() {
		this.router.navigateByUrl('register');
	}
}