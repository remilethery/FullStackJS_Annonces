import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonsService } from 'src/app/services/commons.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {

  constructor(private commonsService: CommonsService, private router: Router) { }

  ngOnInit() {}

  // Navigate to login
	navigateToLogin(): void {
		this.router.navigateByUrl('login');
	}

	// Navigate to advert's list
	navigateToAdvertsList(): void {
		this.router.navigateByUrl('adverts/list');
	}

	// Navigate to advert's create
	navigateToAdvertsCreate(): void {
		this.router.navigateByUrl('advert/create');
  }

  // Logout
	logout(): void {
		this.commonsService.logout();
	}
}
