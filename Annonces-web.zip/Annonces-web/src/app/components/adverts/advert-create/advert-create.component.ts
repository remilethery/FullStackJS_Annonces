import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { Advert } from 'src/app/models/Advert';
import { AdvertsService } from 'src/app/services/adverts.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-advert-create',
  templateUrl: './advert-create.component.html',
  styleUrls: ['./advert-create.component.css']
})
export class AdvertCreateComponent implements OnInit {

  newAdvert: Advert;

  advertForm = new FormGroup({
    inputTitle: new FormControl(),
    inputReference: new FormControl(),
    inputDesc: new FormControl(),

    inputTitleProduct1: new FormControl(),
    inputDescProduct1: new FormControl(),
    inputPriceProduct1: new FormControl(),

    inputTitleProduct2: new FormControl(),
    inputDescProduct2: new FormControl(),
    inputPriceProduct2: new FormControl(),

  });

  constructor(private advertService: AdvertsService, private router: Router) { }

  ngOnInit() {
  }

  advert(formValue: any) {
    this.advertService
      .createAdvert(
        formValue.inputTitle,
        formValue.inputReference,
        formValue.inputDesc,

        formValue.inputTitleProduct1,
        formValue.inputDescProduct1,
        formValue.inputPriceProduct1,

        formValue.inputTitleProduct2,
        formValue.inputDescProduct2,
        formValue.inputPriceProduct2,

      )
      .subscribe(advert => {
        this.navigateToAdvertsList();
      });
  }


  //Navigate to adverts-list
  navigateToAdvertsList() {
    this.router.navigateByUrl('adverts/list');
  }
}
