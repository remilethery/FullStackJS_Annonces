import { Component, OnInit } from '@angular/core';
import { CommonsService } from 'src/app/services/commons.service';
import { Advert } from 'src/app/models/Advert';
import { AdvertsService } from 'src/app/services/adverts.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-advert-list',
  templateUrl: './advert-list.component.html',
  styleUrls: ['./advert-list.component.css']
})
export class AdvertListComponent implements OnInit {

  adverts: Advert[];

  constructor(private advertsServices: AdvertsService, private router: Router) { }

  ngOnInit() {
    this.listAdverts();
  }

  // Get all adverts
  listAdverts(){
    this.advertsServices.getAllAdverts().subscribe(adverts => this.adverts = adverts);
  }

  // Navigate to details
  navigateToAdvertDetails(advert: Advert): void {
    this.advertsServices.setSelectedAdvert(advert);
    this.router.navigateByUrl(`advert/details`);
  }
}
