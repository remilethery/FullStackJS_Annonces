import { Component, OnInit } from '@angular/core';
import { AdvertsService } from 'src/app/services/adverts.service';
import { Advert } from 'src/app/models/Advert';
import { CommonsService } from 'src/app/services/commons.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-advert-details',
  templateUrl: './advert-details.component.html',
  styleUrls: ['./advert-details.component.css']
})
export class AdvertDetailsComponent implements OnInit {

  selectedAdvert: Advert;

  constructor(private advertService: AdvertsService, private router: Router) { }

  ngOnInit() {
    this.subscribeToSelectedAdvert();
  }

  // Subscribe to selected advert
  subscribeToSelectedAdvert(){
    this.advertService.selectedAdvert.subscribe(advert => this.selectedAdvert = advert);
  }
}
