import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AdvertListComponent } from './components/adverts/advert-list/advert-list.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { FooterComponent } from './components/footer/footer.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { LoginComponent } from './components/login/login.component';
import { BasicAuthInterceptor } from './guards/auth.interceptor';
import { ReactiveFormsModule } from '@angular/forms';
import { AdvertDetailsComponent } from './components/adverts/advert-details/advert-details.component';
import { AdvertCreateComponent } from './components/adverts/advert-create/advert-create.component';

@NgModule({
  declarations: [
    AppComponent,
    AdvertListComponent,
    NavbarComponent,
    FooterComponent,
    LoginComponent,
    AdvertDetailsComponent,
    AdvertCreateComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [{ provide: HTTP_INTERCEPTORS, useClass: BasicAuthInterceptor, multi: true}],
  bootstrap: [AppComponent]
})
export class AppModule { }
