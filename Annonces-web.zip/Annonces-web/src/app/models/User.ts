export class User {
    id: number;
    firstName: String;
    lastName: String;
    birthDate: Date;
    gender: String;
    email: String;
    password: String;
    phone: String;
    isAdmin: Boolean;
    registerDate: Date;


    constructor(firstName: string, lastName: string, birhDate: Date, gender: string, email: String,
        password: String, phone: String, isAdmin: Boolean, registerDate: Date){
        this.firstName = firstName;
        this.lastName = lastName;
        this.birthDate = birhDate;
        this.gender = gender;
        this.email = email;
        this.password = password;
        this.phone = phone;
        this.isAdmin = isAdmin;
        this.registerDate = registerDate;
    }
}
