import { User } from "./User";
import { Product } from "./Product"

export class Advert {
    id: number;
    title: String;
    description: String;
    reference: String;
    author: User;
    products: Product[];
    createdDate: Date;

    constructor(title: String, description: String, reference: String, author: User, products: Product[], createdDate: Date){
        this.title = title;
        this.description = description;
        this.reference = reference;
        this.author = author;
        this.products = products;
        this.createdDate = createdDate;
    }
}
