import { SubCategory } from "./SubCategory";

export class Category {
    id: number;
    title: String;
    description: String;
    subCategories: SubCategory[];

    constructor(title: String, description: String, subCategories: SubCategory[]){
        this.title = title;
        this.description = description;
        this.subCategories = subCategories;
    }
}
