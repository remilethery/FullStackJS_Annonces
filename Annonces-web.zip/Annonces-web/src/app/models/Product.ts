import { SubCategory } from "./SubCategory";

export class Product {
    id: number;
    title: String;
    description: String;
    images: String[];
    price: Number
    subCategories: SubCategory[];

    constructor(title: String, description: String, images: String[], price: Number, subCategories: SubCategory[]){
        this.title = title;
        this.description = description;
        this.images = images;
        this.price = price;
        this.subCategories = subCategories;
    }
}
