import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdvertListComponent } from './components/adverts/advert-list/advert-list.component';
import { LoginComponent } from './components/login/login.component';
import { AuthenticateGuard } from './guards/authenticate.guard';
import { AdvertDetailsComponent } from './components/adverts/advert-details/advert-details.component';
import { AdvertCreateComponent } from './components/adverts/advert-create/advert-create.component';
import { AdvertsService } from './services/adverts.service';


const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full'},
  { path: 'login', component: LoginComponent},
  { path: 'adverts/list', component: AdvertListComponent, canActivate: [AuthenticateGuard]},
  { path:'advert/details', component: AdvertDetailsComponent, canActivate: [AuthenticateGuard] },
  { path:'advert/create', component: AdvertCreateComponent, canActivate: [AuthenticateGuard] }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }