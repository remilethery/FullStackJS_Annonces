import { Component } from '@angular/core';
import { CommonsService } from './services/commons.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styles: []
})
export class AppComponent {

  title = 'leboncoin-web';
  isAuthenticate: Boolean;

  constructor(private commonService: CommonsService) { }

  ngOnInit() {
    this.subscribeToIsAuthenticate();
  }

  // Subscribe to term filter of header search bar
  subscribeToIsAuthenticate(){
    this.commonService.isAuthenticate.subscribe(status => this.isAuthenticate = status);
  }
}
