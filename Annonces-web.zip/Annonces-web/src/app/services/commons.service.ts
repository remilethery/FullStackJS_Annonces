import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from '../models/User';
import { Observable, BehaviorSubject } from 'rxjs';
import { map } from 'rxjs/operators';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class CommonsService {

  connectedUser = new BehaviorSubject(null);
	newTerm = new BehaviorSubject(null);
	isAuthenticate = new BehaviorSubject(null);

  constructor(private http: HttpClient, private router: Router) { }

  // Login ang get authentication token
	login(email: string, password: string): Observable<User> {
		return this.http
			.post('http://127.0.0.1:3000/common/login', { "email": email, "password": password })
			.pipe(map((res: any) => {
				let user = res.user;
				localStorage.setItem('token', res.token);
				return new User(user.firstName, user.lastName, user.birthDate, user.gender, user.email, user.password, user.phone, user.isAdmin, user.registerDate);
      })
    )
  }

  // Set connected user
	setConnectedUser(user: User): void {
		this.connectedUser.next(user);
	}

	// Update term filter of search bar
	setNewFilterTerm(term) {
		this.newTerm.next(term);
	}

	// Update isAuthenticate
	setIsAuthenticate(value: Boolean) {
		this.isAuthenticate.next(value);
	}

	// Remove token from localstorage
	logout(): void {
		localStorage.removeItem('token');
		this.setIsAuthenticate(false);
		this.navigateToLogin();
	}

	//Navigate to login
	navigateToLogin() {
		this.router.navigateByUrl('login');
	}

}
