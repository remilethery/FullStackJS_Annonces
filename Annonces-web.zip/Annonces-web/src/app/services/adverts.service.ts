import { Injectable } from '@angular/core';
import { Observable, BehaviorSubject } from 'rxjs';
import { Advert } from '../models/Advert';
import { HttpClient } from '@angular/common/http';
import { map } from "rxjs/operators";
import { Router } from '@angular/router';

@Injectable({
	providedIn: 'root'
})
export class AdvertsService {

	selectedAdvert = new BehaviorSubject(null);


	constructor(private http: HttpClient) { }

	// Get all adverts
	getAllAdverts(): Observable<Advert[]> {
		return this.http.post('http://127.0.0.1:3000/adverts/list', {})
			.pipe(map((adverts: Advert[]) => { return adverts; }))
	}

	// Set selected advert
	setSelectedAdvert(advert: Advert): void {
		this.selectedAdvert.next(advert);
	}

	createAdvert(inputTitle: String, inputReference: String, inputDesc: String,
		inputTitleProduct1: String, inputDescProduct1: String, inputPriceProduct1: String,
		inputTitleProduct2: String, inputDescProduct2: String, inputPriceProduct2: String
	): Observable<any> {

		return this.http.post('http://127.0.0.1:3000/adverts/create', {
			"title": inputTitle, "description": inputDesc, "reference": inputReference,
			"products[0].title": inputTitleProduct1, "products[0].description": inputDescProduct1, "products[0].price": inputPriceProduct1,
			"products[1].title":  inputTitleProduct2, "products[1].description":  inputDescProduct2, "products[1].price":  inputPriceProduct2
		 });
	}

}
