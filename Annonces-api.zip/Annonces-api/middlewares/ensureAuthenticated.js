const jwt = require('jsonwebtoken');

module.exports = (app) => {
    return (req, res, next) => {

        // Get token from request header
        const encryptedToken = req.header('Authorization');

        if (!encryptedToken)
            return res.status(401).send('Unauthorized');

        // Verifiry the token
        jwt.verify(encryptedToken, 'thisIsSecretForJWT', (err, token) => {
            if (err)
                return res.status(401).send(err);

            req.token = token;
            next();
        });
    };
};
