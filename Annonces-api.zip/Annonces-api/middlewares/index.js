module.exports = (app) => {
    app.middlewares = {
        ensureAuthenticated: require('./ensureAuthenticated')(app)
    }
};
