const express = require('express')
const app = express()
var cors = require('cors');

// Uses Cors
app.use(cors());

// Middleware for parsing json
const bodyParser = require('body-parser');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }))

require('./middlewares')(app); console.log('loading middlewares...');
require('./models')(app); console.log('loading models...');
require('./controllers')(app); console.log('loading controllers...');
require('./routes')(app); console.log('loading routes...');

// Use dataset for database
app.controllers.common.dataset();

app.listen(3000, function () {
  console.log('Example app listening on port 3000!')
})