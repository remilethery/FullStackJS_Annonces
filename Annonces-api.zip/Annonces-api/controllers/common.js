const encryptPassword = require('encrypt-password');

encryptPassword.secret = 'Secrect key never changed.';
encryptPassword.min = 8;
encryptPassword.max = 24;
encryptPassword.pattern = /^\w{8,24}$/;

const jwt = require('jsonwebtoken');

module.exports = (app) => {

    // Import models
    const User = app.models.User;
    const Category = app.models.Category;
    const SubCategory = app.models.SubCategory;
    const Product = app.models.Product;
    const Advert = app.models.Advert;

    var map = {}

    let users = [
        new User({firstName: 'Michael', lastName: 'Myers', gender: 'Male', birthDate: new Date('1990-01-01'), phone: '06 06 06 06 06', email: 'michael.myers@gmail.com', password: 'password', isAdmin: true}),
        new User({firstName: 'John', lastName: 'Doe', gender: 'Male', birthDate: new Date('1990-01-01'), phone: '06 06 06 06 06', email: 'john.doe@gmail.com', password: 'differentpassword'})
    ]

    const subCategories = [
        // 'Multimédia' sub categories
        new SubCategory({title: 'Informatique', description: ''}),
        new SubCategory({title: 'Console et jeux vidéo', description: ''}),
        new SubCategory({title: 'Téléphonie', description: ''}),
        // 'Maison' sub categories
        new SubCategory({title: 'Electroménager', description: ''}),
        new SubCategory({title: 'Décoration', description: ''}),
        new SubCategory({title: 'Jardinage', description: ''}),
        // 'Mode' sub categories
        new SubCategory({title: 'Vêtements', description: ''}),
        new SubCategory({title: 'Chaussures', description: ''}),
        new SubCategory({title: 'Montres et Bijoux', description: ''}),
        // 'Immobilier' sub categories
        new SubCategory({title: 'Maison', description: ''}),
        new SubCategory({title: 'Appartement', description: ''}),
        new SubCategory({title: 'Bureaux et commerces', description: ''}),
    ]

    const categories = [
        new Category({title: 'Multimédia', description: 'Tous les catégories qui sont en lien avec le multimédia'}),
        new Category({title: 'Maison', description: 'Tous les catégories qui sont en lien avec la maison'}),
        new Category({title: 'Mode', description: 'Tous les catégories qui sont en lien avec la mode'}),
        new Category({title: 'Immobilier', description: 'Tous les catégories qui sont en lien avec la mode'})
    ]

    const products = [
        // 'Téléphonie'
        new Product({title: 'Samsung Galaxy Note 10+', description: '', images: ['https://dyw7ncnq1en5l.cloudfront.net/optim/produits/36/49925/galaxy-s10_9aefcd10811e83f4__450_400.jpg'], price: 1050}),
        new Product({title: 'LG G7', description: '', images: ['https://images-na.ssl-images-amazon.com/images/I/81hmuAhbo8L._SL1500_.jpg'], price: 450}),
        new Product({title: 'Google Pixel XL', description: '', images: ['https://www.marketphones.com/20887-large_default/google-pixel-xl-4-go-128-go-noir.jpg'], price: 349}),
        // 'Console et jeux vidéo'
        new Product({title: 'Nintendo Switch', description: '', images: ['https://encrypted-tbn0.gstatic.com/shopping?q=tbn:ANd9GcTG53IImD80d3k0LD5PmN7m2XwstZRlMqEWccKyj5Y8stRoUW0uoEKN70N1UW7XmMQV93_wzPA4LUtP7476PsUkUegE8KPtB9vwOkceoCFfIeO6RNZd6vPP&usqp=CAc'], price: 280}),
        new Product({title: 'Playstation 4', description: '', images: ['https://encrypted-tbn1.gstatic.com/shopping?q=tbn:ANd9GcRWj4elM5HeolkNgXc7oj3LRtKiL8bZw01VoFPKPOaKhy1ofS_5QaG9sNu_hhuW5h9Lmjgyf9eavZWWThZAvtO8f-3R0vOLM6Zk58p8QnM46w27xU2LCrfUkg&usqp=CAc'], price: 225}),
        new Product({title: 'Alienware Area 51m', description: '', images: ['https://encrypted-tbn1.gstatic.com/shopping?q=tbn:ANd9GcSF4asIDpUiAPML8zLftrIrMbjEvPG-9IOBtApfk5VYzt3HiWTGflKXW2W_L_q7uWkPeCvBuqxLfsOrPn4fL-VRuD1IBtTmGbmf4nR8SQrrG565L8zI8AcN&usqp=CAc'], price: 3449.50}),
        // 'Informatique'
        new Product({title: 'CANON Imprimante multifonction 4 en 1 PIXMA MX475', description: '', images: ['https://encrypted-tbn0.gstatic.com/shopping?q=tbn:ANd9GcRuK9eFSIsvz0bxp-F5OqjWKcQYUSwS1l99cG4lLlIIt90zp0Rh19R5IkxkbELhlm-2bBMMKMj7YIEvnhIZ00N3gQhmlDPn9Eq_ZuMn0JrMjVlGqbzd7C7znQ&usqp=CAc'], price: 39.80}),
        new Product({title: 'MSI Optix AG32C - Écran LED Incurvé 31,5" - Dalle VA', description: '', images: ['https://encrypted-tbn0.gstatic.com/shopping?q=tbn:ANd9GcTqCJIpx25aip0bDrn7SF4OaoE8LH0K96cJ_2Lcds6uoiFEI3a4ka9ixVsa-9nb8KIHivtDIUURyp_scXteNmG1rmJqS7SHjigLek58DtOhejwR5aoX880T&usqp=CAc'], price: 249}),
        new Product({title: 'AMD Processeur Ryzen 7 3800X Wraith Prism cooler', description: '', images: ['https://encrypted-tbn1.gstatic.com/shopping?q=tbn:ANd9GcQzhF0SUxwl64w9hCLr0GT1pLQYLfq1WUMAKMs94XCNcYkQEsuW0RM7LJimIc5-r-QWP8xOicI0WcKf3NrGwo5_liIExyS-C5W8qvLrQFMLuZpkHaZWtNC4Cw&usqp=CAc'], price: 356.99})
    ]

    const adverts = [
        new Advert({title: `Ecran de PC et Imprimate CANON multifonction`, description: `Je vends mon écran de PC que je n'utilise plus ainsi que mon imprimante`, reference: "REF000001"}),
        new Advert({title: `PC Alienware`, description: `Suite à l'achat d'un nouveau PC portable, je vends mon PC alienware`, reference: "REF000002"}),
        new Advert({title: `Nintendo Switch avec 3 jeux`, description: `Je vends ma switch avec 3 jeux (Mario Galaxy, Super smash bros et Zelda)`, reference: "REF000003"}),
        new Advert({title: `Google Pixel XL et AMD Ryze 7`, description: `Je vends ce pack avec mon téléphone et mon processeur AMD Ryzen 7 3800X Wraith Prism cooler`, reference: "REF000004"})
    ]

    return { login, dataset }

    // Login and generate jwt token
    function login (req, res) {

        checkEmail()
            .then(foundUser => checkPassword(foundUser))
            .then(foundUser => generateToken(foundUser))
            .catch(err => res.send(err))

        // Ensure profile exist
        function checkEmail() {
            return new Promise((resolve, reject) => {
                User.findOne({email: req.body.email}, function (err, user) {
                    if (err) return reject(err);
                    else {
                        if (user){
                            resolve(user);
                        } else {
                            reject();
                            res.status(500).send(`L'adresse mail est introuvable`)
                        }
                    }
                });
            })
        }

        // Ensure password is correct
        function checkPassword(foundUser) {
            return new Promise((resolve, reject) => {
                if( encryptPassword(req.body.password, 'signatrue') == foundUser.password){
                    resolve(foundUser);
                } else {
                    reject();
                    res.status(500).send('Les mots de passe ne sont pas les mêmes !');
                }
            })
        }

        // Generate jsonwebtoken
        function generateToken(foundUser) {
            const token = jwt.sign({id: foundUser.id, user: foundUser.email}, 'thisIsSecretForJWT', {expiresIn: 60 * 60});
            res.json({
                token: token,
                user: foundUser
            });
        }
    }


    // Dataset for database
    function dataset(req, res) {

        encryptPasswordOfUsers()
            .then(addUsers)
            .then(getUsersIds)
            .then(addSubCategories)
            .then(addCategories)
            .then(getSubCategoriesIds)
            .then(getCategoriesIds)
            .then(addSubCategoriesToCagetories)
            .then(addProducts)
            .then(addSubCategoriesToProducts)
            .then(addAdverts)
            .then(getProductsIds)
            .then(addProductsToAdverts)
            .then(addAuthorsToAdverts)
            //.then(res.sendStatus(200))

        // Encrypt all password with encrypt-password
        function encryptPasswordOfUsers() {
            return new Promise((resolve, reject) => {
                let i=0;
                users.forEach(user => {
                    user.password = encryptPassword(user.password, 'signatrue');
                    i++;
                    if( i == users.length) {
                        resolve();
                    }
                });
            });
        }

        // Add users to database
        function addUsers() {
            return new Promise((resolve, reject) => {
                User.insertMany(users, function (err, item) {
                    if (err) return reject(err);
                    else {resolve()}
                });
            })
        }

        // Get users's ids
        function getUsersIds() {
            return new Promise((resolve, reject) => {
                User.find({}, function(err, users) {
                    if (err) return console.error(err);
                    else { users.forEach(user => { map[user.email] = user._id; });resolve();}
                })
            });
        }

        // Add sub categories to database
        function addSubCategories() {
            return new Promise((resolve, reject) => {
                SubCategory.insertMany(subCategories, function (err, item) {
                    if (err) return reject(err);
                    else {resolve()}
                });
            })
        }

        // Add categories to database
        function addCategories() {
            return new Promise((resolve, reject) => {
                Category.insertMany(categories, function (err, item) {
                    if (err) return reject(err);
                    else {resolve()}
                });
            })
        }

        // Get sub categories's ids
        function getSubCategoriesIds() {
            return new Promise((resolve, reject) => {
                SubCategory.find({}, function(err, categories) {
                    if (err) return console.error(err);
                    else { categories.forEach(category => { map[category.title] = category._id; });resolve();}
                })
            });
        }

        // Get categories's ids
        function getCategoriesIds() {
            return new Promise((resolve, reject) => {
                Category.find({}, function(err, categories) {
                    if (err) return console.error(err);
                    else { categories.forEach(category => { map[category.title] = category._id; });resolve();}
                })
            });
        }

        // Add sub categories to categories
        function addSubCategoriesToCagetories() {
            return new Promise((resolve, reject) => {
                Category.findOneAndUpdate({title: 'Multimédia'},{
                    subCategories: [map['Informatique'], map['Console et jeux vidéo'], map['Téléphonie']]}, function(err, category) {
                    if (err) return reject(err);
                });
                Category.findOneAndUpdate({title: 'Maison'},{
                    subCategories: [map['Electroménager'], map['Décoration'], map['Jardinage']]}, function(err, category) {
                    if (err) return reject(err);
                });
                Category.findOneAndUpdate({title: 'Mode'},{
                    subCategories: [map['Vêtements'], map['Chaussures'], map['Montres et bijoux']]}, function(err, category) {
                    if (err) return reject(err);
                });
                Category.findOneAndUpdate({title: 'Immobilier'},{
                    subCategories: [map['Maison'], map['Appartement'], map['Bureaux et commerces']]}, function(err, category) {
                    if (err) return reject(err);
                });
                resolve();
            })
        }

        // Add products to database
        function addProducts() {
            return new Promise((resolve, reject) => {
                Product.insertMany(products, function (err, item) {
                    if (err) return reject(err); else {resolve();}
                });
            })
        }

        // Add sub categories to products
        function addSubCategoriesToProducts() {
            return new Promise((resolve, reject) => {
                Product.updateMany({title: {$in: ['Samsung Galaxy Note 10+', 'LG G7', 'Google Pixel XL']}},
                    {subCategories: [map['Téléphonie']]},function(err, category) {
                    if (err) return reject(err);
                });
                Product.updateMany({title: {$in: ['Nintendo Switch', 'Playstation 4', 'Alienware Area 51m']}},
                    {subCategories: [map['Console et jeux vidéo']]},function(err, category) {
                    if (err) return reject(err);
                });
                Product.updateMany({title: {$in: ['CANON Imprimante multifonction 4 en 1 PIXMA MX475',
                    'MSI Optix AG32C - Écran LED Incurvé 31,5" - Dalle VA',
                    'AMD Processeur Ryzen 7 3800X Wraith Prism cooler']}},
                    {subCategories: [map['Informatique']]},function(err, category) {
                    if (err) return reject(err);
                });
                resolve();
            })
        }

        // Add adverts to database
        function addAdverts() {
            return new Promise((resolve, reject) => {
                Advert.insertMany(adverts, function (err, item) {
                    if (err) return reject(err); else {resolve();}
                });
            })
        }

        // Get products's ids
        function getProductsIds() {
            return new Promise((resolve, reject) => {
                Product.find({}, function(err, products) {
                    if (err) return console.error(err);
                    else { products.forEach(product => { map[product.title] = product._id; });resolve();}
                })
            });
        }

        // Add products to adverts
        function addProductsToAdverts() {
            return new Promise((resolve, reject) => {
                Advert.updateOne({title: 'Ecran de PC et Imprimate CANON multifonction'},
                    { products: [map['MSI Optix AG32C - Écran LED Incurvé 31,5" - Dalle VA'],
                    map['CANON Imprimante multifonction 4 en 1 PIXMA MX475']]},function(err, category) {
                    if (err) return reject(err);
                });
                Advert.updateOne({title: 'PC Alienware'},
                    { products: [map['Alienware Area 51m']]},function(err, category) {
                    if (err) return reject(err);
                });
                Advert.updateOne({title: 'Nintendo Switch avec 3 jeux'},
                    { products: [map['Nintendo Switch']]},function(err, category) {
                    if (err) return reject(err);
                });
                Advert.updateOne({title: 'Google Pixel XL et AMD Ryze 7'},
                    { products: [map['Google Pixel XL'], map['AMD Processeur Ryzen 7 3800X Wraith Prism cooler']]},function(err, category) {
                    if (err) return reject(err);
                });
                resolve();
            })
        }

        // Add products to adverts
        function addAuthorsToAdverts() {
            return new Promise((resolve, reject) => {
                Advert.updateMany({},{ author: map['michael.myers@gmail.com']},function(err, category) {
                    if (err) return reject(err);
                });
                resolve();
            })
        }
    }
 };