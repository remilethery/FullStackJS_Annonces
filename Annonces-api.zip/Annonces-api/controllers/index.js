module.exports = (app) => {
    app.controllers = {
        common: require('./common')(app),
        product: require('./product')(app),
        advert: require('./advert')(app),
        user: require('./user')(app)
    };
};