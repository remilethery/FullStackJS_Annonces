module.exports = (app) => {
    const Product = app.models.Product;

    return { create, list, update, remove};

    // Create a product
    function create(req, res) {

        createProduct()
            .catch(err => console.log(err))

        function createProduct() {
            return new Promise((resolve, reject) => {
                var newProduct = new Product(req.body);
                newProduct.save(function (err, item) {
                    if(err) { res.sendStatus(500); reject(err);};
                    if(item) { res.sendStatus(200); resolve()};
                });
            });
        }
    }

    // List all products
    function list(req, res) {

        listProducts()
            .catch(err => console.log(err))

        function listProducts() {
            return new Promise((resolve, reject) => {
                Product.find({}, function (err, item) {
                    if(err) { res.sendStatus(500); reject(err);};
                    if(item) { res.status(200).send(item); resolve()};
                })
            });
        }
    }

    // Update product
    function update(req, res) {

        updateProduct()
            .catch(err => console.log(err))

        function updateProduct() {
            return new Promise((resolve, reject) => {
                Product.updateOne({title: req.body.title}, req.body, function(err, item) {
                    if(err) { reject(err); res.sendStatus(500); }
                    else { if(item) { resolve(); res.sendStatus(200)} else {reject(500); res.status(500).send('Cannot update product.');};}
                })
            });
        }
    }

    // Remove product
    function remove(req, res) {

        removeProduct()
            .catch(err => console.log(err))

        function removeProduct() {
            return new Promise((resolve, reject) => {
                Product.deleteOne({title: req.body.title}, function(err, item) {
                    if(err) { reject(err); res.sendStatus(500); }
                    else { if(item) { resolve(); res.sendStatus(200)} else {reject(500); res.status(500).send('Cannot remove product.');};}
                })
            });
        }
    }
 };