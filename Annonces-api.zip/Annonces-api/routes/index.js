module.exports = (app) => {
    app.use('/common', require('./common')(app)),
    app.use('/products', require('./product')(app)),
    app.use('/adverts', require('./advert')(app)),
    app.use('/users', require('./user')(app))
};