const router = require('express').Router();

module.exports = (app) => {

    // Create an advert
    router.post('/create',
        app.middlewares.ensureAuthenticated,
        app.controllers.advert.create)

    // List all adverts
    router.post('/list',
        app.middlewares.ensureAuthenticated,
        app.controllers.advert.list)

    // Update an advert
    router.post('/update',
        app.middlewares.ensureAuthenticated,
        app.controllers.advert.update)

    // Remove an advert
    router.post('/remove',
        app.middlewares.ensureAuthenticated,
        app.controllers.advert.remove)

    return router;
};