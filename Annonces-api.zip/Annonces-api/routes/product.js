const router = require('express').Router();

module.exports = (app) => {

    // Create a product
    router.post('/create',
        app.middlewares.ensureAuthenticated,
        app.controllers.product.create)

    // List all products
    router.post('/list',
        app.middlewares.ensureAuthenticated,
        app.controllers.product.list)

    // update product
    router.post('/update',
        app.middlewares.ensureAuthenticated,
        app.controllers.product.update)

    // remove product
    router.post('/remove',
        app.middlewares.ensureAuthenticated,
        app.controllers.product.remove)

    return router;
};